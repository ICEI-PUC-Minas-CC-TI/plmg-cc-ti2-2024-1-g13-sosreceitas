document.addEventListener('DOMContentLoaded', function() {
    fetch('http://localhost:4567/receitas') // Conecta à porta 4567 do servidor backend
      .then(response => response.json())
      .then(data => {
        const recipesDiv = document.getElementById('recipes');
        data.forEach(receita => {
          const receitaDiv = document.createElement('div');
          receitaDiv.classList.add('receita');
          receitaDiv.innerHTML = `
            <h4>${receita.titulo_receitas}</h4>
            <p>${receita.conteudo_receitas}</p>
            <img src="${receita.imagem}" alt="${receita.titulo_receitas}">
          `;
          recipesDiv.appendChild(receitaDiv);
        });
      })
      .catch(error => {
        console.error('Error fetching receitas:', error);
      });
  });
  