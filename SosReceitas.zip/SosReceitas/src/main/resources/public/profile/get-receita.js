document.addEventListener('DOMContentLoaded', function() {
    // Obtém o ID da receita da URL
    const urlParams = new URLSearchParams(window.location.search);
    const recipeId = urlParams.get('id_receitas');
  
    // Verifica se o ID da receita foi encontrado
    if (recipeId) {
      fetch(`http://localhost:4567/receitas/${recipeId}`)
        .then(response => {
          if (!response.ok) {
            throw new Error('Erro ao obter detalhes da receita');
          }
          return response.json();
        })
        .then(recipe => {
          // Preenche os detalhes da receita na página
          const recipeDetailElement = document.getElementById('recipe-detail');
          recipeDetailElement.innerHTML = `
            <p><strong>ID da Receita:</strong> ${recipe.id_receitas}</p>
            <p><strong>ID do Usuário:</strong> ${recipe.id_user}</p>
            <p><strong>Título da Receita:</strong> ${recipe.titulo_receitas}</p>
            <p><strong>Conteúdo da Receita:</strong> ${recipe.conteudo_receitas}</p>
            <img src="${recipe.imagem}" alt="Imagem da Receita">
          `;
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Erro ao obter detalhes da receita');
        });
    } else {
      alert('ID da receita não encontrado na URL');
    }
  });
  