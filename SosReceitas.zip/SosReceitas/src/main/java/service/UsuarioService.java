package service;

import dao.UsuarioDAO;

public class UsuarioService {
	
	private UsuarioDAO usuariodao;
	
	public UsuarioService(){
	usuariodao = new UsuarioDAO();
	}
	
	

}
